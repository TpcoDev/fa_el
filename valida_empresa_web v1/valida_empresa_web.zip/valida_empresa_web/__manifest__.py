# -*- coding: utf-8 -*-
{
    'name': "Ahorasoft TPCO Project",
    'category': 'TPCO',
    'version': '1.0.0',
    'author': "Ahorasoft",
    'website': 'http://www.ahorasoft.com',
    "support": "soporte@ahorasoft.com",
    'summary': """
        Ahorasoft TPCO Project""",
    'description': """
        Ahorasoft TPCO Project
    """,
    "images": [],
    "depends": [
        "website_sale"
    ],
    'data': [
        # 'security/ir.model.access.csv',
        'views/as_template.xml',
    ],
    'qweb': [
    ],
    # 'demo': [
    #     'demo/demo.xml',
    # ],
    'installable': True,
    'auto_install': False,
    
}